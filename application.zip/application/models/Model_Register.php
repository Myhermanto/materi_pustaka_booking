<?php
class Model_Register extends CI_Model{

	function simpan($name,$email,$password){
        $query=$this->db->query("Insert into tbl_register (name,email,password,status,tgl_register) values ('$name','$email','$password','0',now())");
        return $query;
	
	}

}