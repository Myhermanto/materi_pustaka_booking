    <!-- CSS here -->
    <link rel="stylesheet" href="tamplate/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="tamplate/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="tamplate/assets/css/slicknav.css">
    <link rel="stylesheet" href="tamplate/assets/css/flaticon.css">
    <link rel="stylesheet" href="tamplate/assets/css/progressbar_barfiller.css">
    <link rel="stylesheet" href="tamplate/assets/css/gijgo.css">
    <link rel="stylesheet" href="tamplate/assets/css/animate.min.css">
    <link rel="stylesheet" href="tamplate/assets/css/animated-headline.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="tamplate/assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="tamplate/assets/css/themify-icons.css">
    <link rel="stylesheet" href="tamplate/assets/css/slick.css">
    <link rel="stylesheet" href="tamplate/assets/css/nice-select.css">
    <link rel="stylesheet" href="tamplate/assets/css/style.css">