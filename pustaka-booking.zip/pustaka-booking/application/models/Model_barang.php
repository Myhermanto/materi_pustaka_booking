<?php
class Model_barang extends CI_Model{

	function tampil_databarang(){
		$result = $this->db->get('tbl_barang');
		return $result; 
	}

}