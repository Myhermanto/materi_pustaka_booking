<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Tampilan Buku</title>

	
</head>
<body>
<h1>Daftar Buku</h1>

<table border="1">
	<tr>
<td>No</td>
<td>Kode Buku</td>
<td>Nama Buku</td>
<td> Pengarang</td>
<td> Tahun Terbit</td>
<td> Gambar</td>

	</tr>

<tr>
	<td>1</td>
	<td>B001</td>
	<td>Tutorial Web Programmer</td>
	<td>PT. XXXX</td>
	<td>2021</td>
	<td>-</td>
</tr>
</table>

</body>
</html>