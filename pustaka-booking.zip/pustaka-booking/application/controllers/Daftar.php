<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar extends CI_Controller {
	function __construct(){
parent:: __construct();

	$this->load->model('Model_Register');
	}


	public function index()
	{
		$this->load->view('v_daftar');
	}

	function simpan()
	{
		$this->form_validation->set_rules('name', 'full name', 
		'required|min_length[3]', [
 			'required' => 'nama Harus diisi',
 			'min_lenght' => 'nama terlalu pendek'
 			]);
			 
 		$this->form_validation->set_rules('email', 'email', 
		'required|min_length[5]', [
 		'required' => 'email Harus diisi',
 		'min_lenght' => 'email terlalu pendek'
 		]);
		 
 	if ($this->form_validation->run() != true) {
		echo $this->session->set_flashdata('msg','Gagal simpan');
		redirect('Daftar');
 		} else {
			$name=$this->input->post('name');
			$email=$this->input->post('email');
			$password=$this->input->post('password');
			 
			 $this->Model_Register->simpan($name,$email,$password);
			echo $this->session->set_flashdata('msg','Data Berhasil disimpan');
			redirect('Daftar');
 		}
}



}